﻿Public Class HomeUser
    Private Sub viewContactToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles viewContactToolStripMenuItem.Click
        ViewContact.ShowDialog()
    End Sub

    Private Sub searchContactToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles searchContactToolStripMenuItem.Click
        ShowContact.ShowDialog()
    End Sub

    Private Sub exitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles exitToolStripMenuItem.Click
        Hide()
        Form1.ShowDialog()
    End Sub
End Class