﻿Public Class HomeAdmin
    Private Sub viewContactToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles viewContactToolStripMenuItem.Click
        ViewContact.ShowDialog()
    End Sub

    Private Sub updateContactToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles updateContactToolStripMenuItem.Click
        UpdateContact.ShowDialog()
    End Sub

    Private Sub searchContactToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles searchContactToolStripMenuItem.Click
        ShowContact.ShowDialog()
    End Sub

    Private Sub registerNewContactToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles registerNewContactToolStripMenuItem.Click
        RegisterNewContact.ShowDialog()
    End Sub

    Private Sub exitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles exitToolStripMenuItem.Click
        Hide()
        Form1.ShowDialog()
    End Sub
End Class