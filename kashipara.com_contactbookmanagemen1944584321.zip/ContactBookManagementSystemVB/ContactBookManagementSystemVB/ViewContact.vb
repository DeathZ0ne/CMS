﻿Imports System.Data.SqlClient

Public Class ViewContact
    Dim con As SqlConnection
    Dim com As SqlCommand
    Dim dr As SqlDataReader
    Dim gen As String
    Dim str As String
    Dim getuser As String
    Dim da As SqlDataAdapter
    Dim dt As DataTable
    Dim dv As DataView
    Dim cont As Object
    Private Sub button1_Click(sender As Object, e As EventArgs) Handles button1.Click
        con = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\dell\Documents\Visual Studio 2015\Projects\ContactBookManagementSystemVB\ContactBookManagementSystemVB\Contact.mdf;Integrated Security=True")
        con.Open()
        Try
            str = "Select name,gender,mob,email,addr,job,pass from user1 where id='" + textBox1.Text + "'"
            com = New SqlCommand(str, con)
            dr = com.ExecuteReader()
            If dr.Read() Then


                textBox2.Text = dr.GetValue(0).ToString()
                Select Case dr("gender").ToString()
                    Case "Male"
                        radioButton1.Checked = True
                    Case "Female"
                        radioButton2.Checked = True
                End Select
                textBox3.Text = dr.GetValue(2).ToString()
                textBox4.Text = dr.GetValue(3).ToString()
                textBox5.Text = dr.GetValue(4).ToString()
                textBox6.Text = dr.GetValue(5).ToString()
                textBox7.Text = dr.GetValue(6).ToString()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub button2_Click(sender As Object, e As EventArgs) Handles button2.Click
        textBox7.Text = ""
        textBox1.Text = ""
        textBox2.Text = ""
        textBox3.Text = ""
        textBox4.Text = ""
        textBox5.Text = ""
        textBox6.Text = ""
        radioButton1.Checked = True

    End Sub
End Class